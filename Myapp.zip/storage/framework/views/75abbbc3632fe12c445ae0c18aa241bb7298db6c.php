<!DOCTYPE html>
<html>
<head>
	<title>TEMPORADAS</title>
</head>
<body>
<center>
	<form>
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" placeholder="First name">
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="Last name">
    </div>
  </div>
</form>
	
		
	</form> --}}
</center>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/temporadas/agregar.blade.php ENDPATH**/ ?>