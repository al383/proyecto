<form action="<?php echo e(url('/productor/'.$productor->id)); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


<label ><?php echo e('Nombre'); ?></label>	
<input type="text" name="nombre" id="nombre" value="<?php echo e($productor->nombre); ?>">
<br/>

<label ><?php echo e('RFC'); ?></label>	
<input type="text" name="RFC" id="RFC" value="<?php echo e($productor->RFC); ?>">
<br/>

<label ><?php echo e('Telefono de oficiona'); ?></label>	
<input type="text" name="telefono_oficina" id="telefono_oficina" value="<?php echo e($productor->telefono_oficina); ?>">
<br/>

<label ><?php echo e('Telefono celular'); ?></label>	
<input type="text" name="telefono_celular" id="telefono_celular" value="<?php echo e($productor->telefono_celular); ?>">
<br/>

<label ><?php echo e('Correo'); ?></label>	
<input type="email" name="correo" id="correo" value="<?php echo e($productor->correo); ?>">
<br/>

<label ><?php echo e('Tipo de contrato'); ?></label>	
<input type="text" name="tipo_contrato" id="tipo_contrato" value="<?php echo e($productor->tipo_contrato); ?>">
<br/>

<input type="submit" value="Editar">
|<a href="http://localhost/Estadias/Myapp/public/productor">Regresar</a>
</form><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/productores/edit.blade.php ENDPATH**/ ?>