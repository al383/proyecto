<form action="<?php echo e(url('/comercializacion/'.$comercializacion->id)); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


<label ><?php echo e('Numero de entrega'); ?></label>	
<input type="text" name="no_entrega" id="no_entrega" value="<?php echo e($comercializacion->no_entrega); ?>">
<br/>

<label ><?php echo e('Cliente'); ?></label>	
<input type="text" name="cliente" id="cliente" value="<?php echo e($comercializacion->cliente); ?>">
<br/>

<input type="submit" value="Editar">
</form><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/comercializacion/edit.blade.php ENDPATH**/ ?>