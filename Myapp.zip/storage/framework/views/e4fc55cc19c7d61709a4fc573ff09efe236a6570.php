Registro de datos

<form action="<?php echo e(url('/master')); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<label for="Nombre"><?php echo e('Nombre'); ?></label>	
<input type="text" name="Nombre" id="Nombre" value="">
<br/>

<label for="ApellidoPaterno"><?php echo e('Apellido Paterno'); ?></label>	
<input type="text" name="ApellidoPaterno" id="ApellidoPaterno" value="">
<br/>

<label for="ApellidoMaterno"><?php echo e('Apellido Materno'); ?></label>	
<input type="text" name="ApellidoMaterno" id="ApellidoMaterno" value="">
<br/>

<label for="Correo"><?php echo e('Correo'); ?></label>	
<input type="email" name="Correo" id="Correo" value="">
<br/>

<input type="submit" value="Agregar">
</form><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/1mp/create.blade.php ENDPATH**/ ?>