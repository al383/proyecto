<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paca extends Model
{
 	protected $table ='pacas';
}
