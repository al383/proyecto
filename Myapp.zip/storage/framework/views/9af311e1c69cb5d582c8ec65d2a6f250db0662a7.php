<!DOCTYPE html>
<html>
<head>
	<title>LIQUIDACIONES</title>
</head>
<body>
<center>
		<form action="<?php echo e(url('liquidar')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			
			<label><?php echo e('Numero de liquidaciones'); ?></label>
			<input type="text" name="no_liquidacion" placeholder="numero de liquidacion">
			<br>
			<label><?php echo e('Fecha'); ?></label>
			<input type="date" name="fecha" placeholder="escriba la fecha">
			<br>
			<label><?php echo e('Precio de paca'); ?></label>
			<input type="number" min="1" name="precio_paca" placeholder="precio de la paca">
			<br>
			<label><?php echo e('Lote'); ?></label>
			<input type="text" name="lote" placeholder="lote">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/liquidaciones/agregar.blade.php ENDPATH**/ ?>