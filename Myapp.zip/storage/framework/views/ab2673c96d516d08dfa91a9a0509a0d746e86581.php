<form action="<?php echo e(url('/temporada/'.$temporada->id)); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


<label ><?php echo e('Temporada'); ?></label>	
<input type="text" name="temporadas" id="temporadas" value="<?php echo e($temporada->temporadas); ?>">
<br/>

<input type="submit" value="Editar">
</form><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/temporadas/edit.blade.php ENDPATH**/ ?>