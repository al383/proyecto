Inicio (despliegue de datos)

<a href="<?php echo e(url('master/create')); ?>">Agregar</a>

<table class="table table-light">
	<thead class="thead-light">
		<tr>
			<th>#</th>
			<th>Nombre</th>
			<th>Apellido Paterno</th>
			<th>Apellido Materno</th>
			<th>Correo</th>
			<th>Acciones</th>
		</tr>
	</thead>


	<tbody>
		<?php $__currentLoopData = $master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($loop->iteration); ?></td>
			<td><?php echo e($mas->Nombre); ?></td>
			<td><?php echo e($mas->ApellidoPaterno); ?></td>
			<td><?php echo e($mas->ApellidoMaterno); ?></td>
			<td><?php echo e($mas->Correo); ?></td>
			<td>
				<a href="<?php echo e(url('/master/'.$mas->id.'/edit')); ?>">
					Editar
				</a>


			 |

				<form method="post" action="<?php echo e(url('/master/'.$mas->id)); ?>">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('DELETE')); ?>

				<button type="submite" onclick="return confirm('¿desea borrar?');">Borrar</button>
			</form>
			</td>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>

</table><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/1mp/indexF.blade.php ENDPATH**/ ?>