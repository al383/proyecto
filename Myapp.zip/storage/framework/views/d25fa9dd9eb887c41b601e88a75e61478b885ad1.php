<!DOCTYPE html>
<html>
<head>
	<title>PRODUCTOR</title>
</head>
<body>
<center>
		<form action="<?php echo e(url('/productor')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			
			<label><?php echo e('Nombre'); ?></label>
			<input type="text" name="nombre" placeholder="nombre del productor">
			<br>
			<label><?php echo e('RFC'); ?></label>
			<input type="text" name="RFC" placeholder="escriba el RFC">
			<br>
			<label><?php echo e('Telefono de oficiona'); ?></label>
			<input type="text" name="telefono_oficina" placeholder="telefono de oficina">
			<br>
			<label><?php echo e('Telefono celular'); ?></label>
			<input type="text" name="telefono_celular" placeholder="telefono celular">
			<br>
			<label><?php echo e('Correo'); ?></label>
			<input type="email" name="correo" placeholder="escriba su Correo">
			<br>
			<label><?php echo e('Tipo de contrato'); ?></label>
			<input type="text" name="tipo_contrato" placeholder="escriba el tipo de contrato">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/productores/agregar.blade.php ENDPATH**/ ?>