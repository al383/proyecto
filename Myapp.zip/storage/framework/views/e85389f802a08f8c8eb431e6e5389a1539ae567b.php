<form action="<?php echo e(url('/cliente/'.$cliente->id)); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


<label ><?php echo e('Nombre'); ?></label>	
<input type="text" name="nombre" id="nombre" value="<?php echo e($cliente->nombre); ?>">
<br/>

<label ><?php echo e('Nombre de la empresa'); ?></label>	
<input type="text" name="empresa" id="empresa" value="<?php echo e($cliente->empresa); ?>">
<br/>

<label ><?php echo e('Direccion del cliente'); ?></label>	
<input type="text" name="direccion" id="direccion" value="<?php echo e($cliente->direccion); ?>">
<br/>

<label ><?php echo e('Ciudad'); ?></label>	
<input type="text" name="ciudad" id="ciudad" value="<?php echo e($cliente->ciudad); ?>">
<br/>

<label ><?php echo e('Colonia'); ?></label>	
<input type="text" name="colonia" id="colonia" value="<?php echo e($cliente->colonia); ?>">
<br/>

<label ><?php echo e('RFC'); ?></label>	
<input type="text" name="RFC" id="RFC" value="<?php echo e($cliente->RFC); ?>">
<br/>

<label ><?php echo e('Telefono de oficiona'); ?></label>	
<input type="text" name="telefono_oficina" id="telefono_oficina" value="<?php echo e($cliente->telefono_oficina); ?>">
<br/>

<label ><?php echo e('Telefono celular'); ?></label>	
<input type="text" name="telefono_celular" id="telefono_celular" value="<?php echo e($cliente->telefono_celular); ?>">
<br/>

<label ><?php echo e('Correo'); ?></label>	
<input type="email" name="correo" id="correo" value="<?php echo e($cliente->correo); ?>">
<br/>

<input type="submit" value="Editar">
</form><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/cliente/edit.blade.php ENDPATH**/ ?>