<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comercializacion extends Model
{
   protected $table ='comercializacion';
}
