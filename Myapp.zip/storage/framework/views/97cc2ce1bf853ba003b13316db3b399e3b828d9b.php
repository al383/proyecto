<!DOCTYPE html>
<html>
<head>
	<title>ABONOS</title>
</head>
<body>
<center>
<form action="<?php echo e(url('/abono')); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<label for="NoPago"><?php echo e('Número de pagos'); ?></label>	
<input type="number" name="NoPago" id="NoPago" value="" placeholder="">
<br>

<label for="NoFactura"><?php echo e('Número de facturas'); ?></label>	
<input type="number" name="NoFactura" id="NoFactura" value="">
<br>

<label for="cantidad"><?php echo e('Cantidad'); ?></label>	
<input type="number" name="cantidad" id="cantidad" value="">
<br>

<label for="fecha"><?php echo e('Fecha'); ?></label>	
<input type="text" name="fecha" id="fecha" value="">
<br>
<br>
<input type="submit" value="Agregar">
</form>
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/abonos/agregar.blade.php ENDPATH**/ ?>