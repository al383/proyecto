<!DOCTYPE html>
<html>
<head>
	<title>PACAS</title>
</head>
<body>
<center>
		<form action="<?php echo e(url('/pacas')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			
			
			<label><?php echo e('Modulo'); ?></label>
			<input type="text" name="modulo" placeholder="modulo">
			<br>
			<label><?php echo e('Peso paca'); ?></label>
			<input type="number" name="peso_paca" placeholder="peso paca">
			<br>
			<label><?php echo e('Lote'); ?></label>
			<input type="text" name="lote" placeholder="lote">
			<br>
			<label><?php echo e('Temporada'); ?></label>
			<input type="text" name="temporada" placeholder="temporada">
			<br>
			<label><?php echo e('Peso modulo'); ?></label>
			<input type="text" name="peso_modulo" placeholder="peso modulo">
			<br>
			<label><?php echo e('Estatus liquidacion'); ?></label>
			<input type="text" name="estatus_liquidacion" placeholder="estatus liquidacion">
			<br>
			<label><?php echo e('Clasificacion HBI'); ?></label>
			<input type="text" name="clasificacion_HBI" placeholder="clasificacion HBI">
			<br>
			<label><?php echo e('Estatus comercializacion'); ?></label>
			<input type="text" name="estatus_comercializacion" placeholder="estatus comercializacion">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/pacas/agregar.blade.php ENDPATH**/ ?>