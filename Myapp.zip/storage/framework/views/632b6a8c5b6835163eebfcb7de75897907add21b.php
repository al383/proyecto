<!DOCTYPE html>
<html>
<head>
	<title>COMERCIALIZACION</title>
</head>
<body>
Apartado de comercialización
<center>
		<form action="<?php echo e(url('/comercializacion')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<label><?php echo e('Numero de entrega'); ?></label>
			<input type="text" name="no_entrega" placeholder="numero de entrega">
			<br>
			<label><?php echo e('Cliente'); ?></label>
			<input type="text" name="cliente" placeholder="Solo numeros">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/comercializacion/agregar.blade.php ENDPATH**/ ?>