<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<title>LOTE</title>
</head>
<body>
	<center>
		<form action="<?php echo e(url('/lote')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<label><?php echo e('Lote'); ?></label>
			<input type="number" min="1" name="lote" placeholder="lote">
			<br>
			<label><?php echo e('Id del productor'); ?></label>
			<input type="number" name="productor" placeholder="Id del productor">
			<br>
			<label><?php echo e('Direccion'); ?></label>
			<input type="text" name="direccion" placeholder="direccion">
			<br>
			<label><?php echo e('Ciudad'); ?></label>
			<input type="text" name="ciudad" placeholder="ciudad">
			<br>
			<label><?php echo e('Localidad'); ?></label>
			<input type="text" name="localidad" placeholder="localidad">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/lote/agregar.blade.php ENDPATH**/ ?>