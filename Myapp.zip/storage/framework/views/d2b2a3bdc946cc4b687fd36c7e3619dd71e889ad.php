<!DOCTYPE html>
<html>
<head>
	<title>CLIENTES</title>
</head>
<body>
Apartado de clientes
<center>
		<form action="<?php echo e(url('/cliente')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<label><?php echo e('Nombre'); ?></label>
			<input type="text" name="nombre" placeholder="nombre del cliente">
			<br>
			<label><?php echo e('Nombre de la empresa'); ?></label>
			<input type="text" name="empresa" placeholder="nombre de la empresa">
			<br>
			<label><?php echo e('Direccion del cliente'); ?></label>
			<input type="text" name="direccion" placeholder="direccion del cliente">
			<br>
			<label><?php echo e('Ciudad'); ?></label>
			<input type="text" name="ciudad" placeholder="ciudad">
			<br>
			<label><?php echo e('Colonia'); ?></label>
			<input type="text" name="colonia" placeholder="colonia">
			<br>
			<label><?php echo e('RFC'); ?></label>
			<input type="text" name="RFC" placeholder="escriba el RFC">
			<br>
			<label><?php echo e('Telefono de oficiona'); ?></label>
			<input type="text" name="telefono_oficina" placeholder="telefono de oficina">
			<br>
			<label><?php echo e('Telefono celular'); ?></label>
			<input type="text" name="telefono_celular" placeholder="telefono celular">
			<br>
			<label><?php echo e('Correo'); ?></label>
			<input type="email" name="correo" placeholder="escriba su Correo">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/cliente/agregar.blade.php ENDPATH**/ ?>