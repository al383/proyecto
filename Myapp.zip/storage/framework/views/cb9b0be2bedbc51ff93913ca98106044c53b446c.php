<!DOCTYPE html>
<html>
<head>
	<title>FACTURAS</title>
</head>
<body>
<center>
		<form action="<?php echo e(url('/facturas')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<label><?php echo e('Numero de factura'); ?></label>
			<input type="text" name="no_factura" placeholder="numero de factura">
			<br>
			<label><?php echo e('Numero de liquidacion'); ?></label>
			<input type="text" name="no_liquidacion" placeholder="numero de liquidacion">
			<br>
			<label><?php echo e('Observaciones'); ?></label>
			<input type="text" name="observaciones" placeholder="observaciones">
			<br>
			<label><?php echo e('Estatus'); ?></label>
			<input type="text" name="estatus" placeholder="estatus">
			<br>
			<label><?php echo e('Total'); ?></label>
			<input type="text" name="total" placeholder="total">
			<br>
			<label><?php echo e('Debe'); ?></label>
			<input type="text" name="debe" placeholder="cantidad que debe">
			<br>
			<br>
			<button type="submit">Agregar</button>
		</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/facturas/agregar.blade.php ENDPATH**/ ?>