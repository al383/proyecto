<title>HBR</title>
        <link rel="icon" type="image/x-icon" href="../img/HBR.jpg" />
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="border-color: #9c9c9c;">
                <div class="card-header" style="background-color: #9c9c9c; color: black"><?php echo e(__('Mensaje')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('¡Administrador, estás conectado!,
                    presioné laravel para ingresar al sistema')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/home.blade.php ENDPATH**/ ?>