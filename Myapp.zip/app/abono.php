<?php

namespace App;

// use App\abono;
use Illuminate\Database\Eloquent\Model;

class abono extends Model
{
    //
    protected $table ='abonos'; 
}
