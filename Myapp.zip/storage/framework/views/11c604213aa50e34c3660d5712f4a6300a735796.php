<form action="<?php echo e(url('/master/'.$mas->id)); ?>" method="post" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


<label for="Nombre"><?php echo e('Nombre'); ?></label>	
<input type="text" name="Nombre" id="Nombre" value="<?php echo e($mas->Nombre); ?>">
<br/>

<label for="ApellidoPaterno"><?php echo e('Apellido Paterno'); ?></label>	
<input type="text" name="ApellidoPaterno" id="ApellidoPaterno" value="<?php echo e($mas->ApellidoPaterno); ?>">
<br/>

<label for="ApellidoMaterno"><?php echo e('Apellido Materno'); ?></label>	
<input type="text" name="ApellidoMaterno" id="ApellidoMaterno" value="<?php echo e($mas->ApellidoMaterno); ?>">
<br/>

<label for="Correo"><?php echo e('Correo'); ?></label>	
<input type="email" name="Correo" id="Correo" value="<?php echo e($mas->Correo); ?>">
<br/>

<input type="submit" value="Editar">
</form><?php /**PATH C:\xampp\htdocs\Estadias\Myapp\resources\views/1mp/edit.blade.php ENDPATH**/ ?>